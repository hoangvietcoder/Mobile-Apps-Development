package com.example.lab4_ex4;

public interface MyPCClickListener {
    void onMyPCClicked (PC pc, int position);
}
